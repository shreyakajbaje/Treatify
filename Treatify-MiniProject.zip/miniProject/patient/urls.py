from django.urls import path
from . import views
from django.conf.urls import url
import accounts.urls,accounts.views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
#set urls
urlpatterns = [
    path('',views.patient,name="patient"), #hmepage for patient
    path('appointment',views.appointment,name="appointment"),#take appointment
    path('bill',views.bill,name="bill"),#check the recent bill    
    path('logout',views.p_logout,name="logout"),#logout for patient
    path('del_bill',views.del_bill,name="del_bill"),#delete my bill
    path('view_bills',views.view_bills,name="view_bills"),#viw all bills

]

urlpatterns += staticfiles_urlpatterns()