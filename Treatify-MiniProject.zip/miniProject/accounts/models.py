from django.db import models
from django.shortcuts import render,redirect
from django.http import HttpResponse
# Create your models here.
