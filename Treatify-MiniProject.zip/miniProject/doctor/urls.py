from django.urls import path
from . import views
from django.conf.urls import url
import accounts.urls,accounts.views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
# set specific URLs
urlpatterns = [
    path('',views.doctor,name="doctor"), #homepage for doctors
    path('recep_reg',views.register,name="register"), #register receptionist
    path('d_bill',views.d_bill,name="d_bill"), #update bill
    path('s_hours',views.s_hours,name="s_hours"), #set new timing
    path('treat_list',views.treat_list,name="treat_list"), #display patient list
    path('d_logout',views.d_logout,name="d_logout"), #logout for doctor
    #Other links to browse
    path('blog-home',views.blog_home,name="blog_home"), 
    path('blog-single',views.blog_single,name="blog_single"),
]

