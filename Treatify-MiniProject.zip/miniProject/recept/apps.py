from django.apps import AppConfig


class ReceptConfig(AppConfig):
    name = 'recept'
